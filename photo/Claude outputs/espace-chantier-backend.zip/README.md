# Espace Chantier — Artisan de Confiance du 13

Backend + API de coordination des travaux : ordonnancement automatique des corps de métier,
planning, gestion des retards en cascade, disponibilités du client (semaine type), et
convocations des artisans par email avec **invitation agenda (.ics)** — le tout via des
**liens personnels** (l'artisan et le client n'ont pas de compte à créer).

> **Où on en est.** Le **backend est complet et testé** (API, moteur d'ordonnancement,
> retards, emails Brevo, liens magiques, .ics). Les **pages artisan et client** (accessibles
> par lien perso) sont fonctionnelles. L'**interface complète du coordinateur** (celle du
> prototype) se branchera sur cette API à l'étape suivante — en attendant on pilote par l'API.

---

## 1. Tester en local (2 minutes)

Il te faut **Node 18+** installé sur ton ordinateur.

```bash
npm install
cp .env.example .env      # puis ouvre .env et mets un ADMIN_PASSWORD
npm start
```

Ouvre http://localhost:3000. Sans clé Brevo, les emails ne sont pas envoyés : ils
s'affichent dans le terminal (mode « dry-run »), pratique pour tester.

Créer un chantier (depuis un terminal, en remplaçant `TON_MOT_DE_PASSE`) :

```bash
curl -X POST http://localhost:3000/api/chantiers \
  -H "authorization: Bearer TON_MOT_DE_PASSE" -H "content-type: application/json" \
  -d '{"nom":"Salle de bain — Villa","client":"M. Dupont","clientEmail":"client@mail.fr","type":"Salle de bain","adresse":"12 chemin des Oliviers, Aix","dateDebut":"2026-09-14"}'
```

La réponse contient un `clientLink` (le lien à envoyer au client). Chaque intervention a
aussi son `token` d'artisan → lien `TON_URL/?a=LE_TOKEN`.

---

## 2. Créer le compte Brevo (emails)

1. Crée un compte sur **brevo.com** (gratuit jusqu'à ~300 emails/jour).
2. **Senders & IP** → ajoute et **valide l'adresse expéditeur** (ex. `contact@artisandeconfiance13.fr`).
   Idéalement, valide aussi ton **domaine** (SPF/DKIM) pour ne pas tomber en spam — Brevo te
   donne les enregistrements DNS à ajouter chez ton hébergeur de domaine.
3. **SMTP & API → API Keys** → crée une clé. Copie-la : c'est ta `BREVO_API_KEY`.

---

## 3. Déployer sur Railway (recommandé)

1. Crée un compte sur **railway.app** (connexion avec GitHub).
2. Mets ce dossier sur **GitHub** (un nouveau dépôt privé), puis dans Railway :
   **New Project → Deploy from GitHub repo** → choisis le dépôt.
   *(Alternative sans GitHub : `npm i -g @railway/cli`, puis `railway init` et `railway up`.)*
3. Railway détecte Node tout seul. Vérifie que la commande de démarrage est `npm start`.
4. **Variables** (onglet Variables du service) — ajoute :

   | Variable          | Valeur                                            |
   |-------------------|---------------------------------------------------|
   | `ADMIN_PASSWORD`  | un mot de passe solide (le tien, coordinateur)    |
   | `BASE_URL`        | l'URL publique (voir étape 5), ex. `https://espace.artisandeconfiance13.fr` |
   | `BREVO_API_KEY`   | la clé de l'étape 2                               |
   | `MAIL_FROM`       | `contact@artisandeconfiance13.fr`                 |
   | `MAIL_FROM_NAME`  | `Artisan de Confiance du 13`                      |
   | `DATA_DIR`        | `/data`                                           |

5. **Persistance des données** : onglet **Volumes → New Volume**, monte-le sur `/data`.
   (Sans ça, les données seraient effacées à chaque redéploiement.)
6. **Domaine** : onglet **Settings → Networking**. Soit tu utilises l'URL Railway fournie,
   soit tu ajoutes ton sous-domaine `espace.artisandeconfiance13.fr` : Railway te donne un
   **CNAME** à créer chez ton registrar. Une fois actif, mets cette URL dans `BASE_URL`.

Render fonctionne pareil (New → Web Service → Build `npm install`, Start `npm start`, un
Disk monté sur `/data`, mêmes variables).

---

## 4. Sécurité (important)

- Choisis un **`ADMIN_PASSWORD` long et unique**.
- L'app doit être servie en **HTTPS** (Railway/Render le font automatiquement).
- Les liens perso (artisan/client) contiennent un jeton secret : ne les publie pas.

---

## 5. Ce qu'il reste à faire (prochaine étape)

- Brancher l'**interface complète du coordinateur** (le prototype) sur cette API.
- Le **rattrapage des conflits** en cas de retard (l'artisan refuse le nouveau créneau →
  re-planification locale à partir de lui).
- Option **SMS** (via un fournisseur) en plus de l'email.

---

## Structure du projet

```
src/
  engine.js   moteur métier (métiers, modèles, ordonnancement jours ouvrés, retards)
  store.js    stockage (fichier JSON ; interface prête pour passer à SQLite/Postgres)
  email.js    envoi via Brevo (dry-run si pas de clé)
  ics.js      génération des invitations agenda .ics
  server.js   API Express + service des pages
public/
  index.html  pages Artisan (?a=token) et Client (?c=token)
```

## Aperçu de l'API

| Méthode | Route | Accès | Rôle |
|--------|-------|-------|------|
| POST | `/api/login` | public | valider le mot de passe coordinateur |
| GET/PUT | `/api/state` | coordinateur | lire / enregistrer l'état complet |
| POST | `/api/chantiers` | coordinateur | créer un chantier (ordre auto) |
| POST | `/api/interventions/:id/notify` | coordinateur | envoyer la convocation (email + .ics) |
| POST | `/api/interventions/:id/delay` | coordinateur | simuler / appliquer un retard |
| GET | `/api/a/:token` | lien artisan | voir son intervention |
| POST | `/api/a/:token/confirm` | lien artisan | confirmer |
| GET | `/api/c/:token` | lien client | voir son chantier |
| POST | `/api/c/:token/availability` | lien client | enregistrer semaine type + absences |
